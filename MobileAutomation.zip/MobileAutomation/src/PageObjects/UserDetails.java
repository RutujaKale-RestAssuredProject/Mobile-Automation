package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UserDetails {
	WebDriver driver;
	
	public UserDetails(WebDriver d) {
		driver =d;
	}

	public void User_Details () {		
		driver.findElement(By.id("name")).sendKeys("Rutuja");
		driver.findElement(By.id("country")).sendKeys("United Arab Emirates");
		driver.findElement(By.id("city")).sendKeys("Dubai");
		driver.findElement(By.id("card")).sendKeys("1455 1122 3322");
		driver.findElement(By.id("month")).sendKeys("04");
		driver.findElement(By.id("year")).sendKeys("25");
	}

}