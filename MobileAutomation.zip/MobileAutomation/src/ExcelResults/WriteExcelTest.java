package ExcelResults;
	
import org.testng.annotations.Test;
import ExcelResults.WriteExcel;

public class WriteExcelTest {

	 WriteExcel obj= new WriteExcel();
	 
	 @Test
	 public void writeExcelTest() throws Exception {
	  obj.writeExcel("Sheet1", "111", 4, 4);
	 }
	 
	 @Test
	 public void writeExcelTest1() throws Exception {
	  obj.writeExcel("Sheet1", "Female", 1, 2);
	 }
}
