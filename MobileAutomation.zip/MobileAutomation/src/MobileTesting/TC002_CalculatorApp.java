package MobileTesting;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class TC002_CalculatorApp {

    public AppiumDriver<MobileElement> driver = null;
    
    @BeforeTest
    public void setupstart() throws MalformedURLException {
        DesiredCapabilities capabilities = DesiredCapabilities.android();
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Rutuja");
        capabilities.setCapability(MobileCapabilityType.UDID, "emulator-5554");
        capabilities.setCapability("appPackage", "com.sec.android.app.popupcalculator");
        capabilities.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");
        driver = new AndroidDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"), capabilities);
    }
 
    @Test
    public void calcTest1() throws Exception {
        driver.findElement(By.xpath("//android.widget.Button[@content-desc='4']")).click();
        driver.findElement(By.xpath("//android.widget.Button[@content-desc='Multiplication']")).click();
        driver.findElement(By.xpath("//android.widget.Button[@content-desc='3']")).click();
        driver.findElement(By.xpath("//android.widget.Button[@content-desc='Equal']")).click();
        String result = driver.findElement(By.className("android.widget.EditText")).getText();
        System.out.println("Result : " + result);
    }
 
    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}