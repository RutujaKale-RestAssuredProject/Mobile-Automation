package MobileTesting;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class TC001_MobileAutomation {
	
    WebDriver driver;
   @Test 
	public void main() throws InterruptedException, IOException {
	
		DesiredCapabilities capabilities = DesiredCapabilities.android();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "Chrome");
		capabilities.setCapability("chromedriverExecutable", "C:\\Program Files\\Appium Server GUI\\resources\\app\\node_modules\\appium\\node_modules\\appium-chromedriver\\chromedriver.exe");
		capabilities.setCapability("udid", "emulator-5556");
		capabilities.setCapability("deviceName", "Rutuja");
		capabilities.setCapability(CapabilityType.VERSION,"11.0");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "11.0");
		capabilities.setCapability("automationName", "Appium");
		WebDriver driver = new RemoteWebDriver (new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
		
		// Navigate to the page and interact with the elements on the guinea-pig page using id.
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		
		//Blank Page Screenshot
		File BlankForm = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(BlankForm, new File("C:/TC001_MobileAutomation/BlankForm.jpg"));
		Thread.sleep(5000);	
		
		//Text Fields
        driver.findElement(By.name("firstname")).sendKeys("Rutuja"); //First Name
        driver.findElement(By.name("lastname")).sendKeys("Vichare"); //Last Name
        Thread.sleep(5000);
        
        //Radio Buttons
        driver.findElement(By.id("sex-1")).click(); //Gender
        driver.findElement(By.id("exp-4")).click(); //Years of Experience
        Thread.sleep(5000);        
        
        //Date Picker
        driver.findElement(By.id("datepicker")).sendKeys("20/09/2022"); //Date
        Thread.sleep(5000); 
        
        //Multiple Choice Boxes
        driver.findElement(By.id("profession-0")).click(); //Profession
        driver.findElement(By.id("profession-1")).click(); //Profession
        driver.findElement(By.id("tool-2")).click(); //Automation Tools
        
        //Dropdown Selection
        Select Continets = new Select (driver.findElement(By.id("continents"))); //Select Continet
        Continets.selectByVisibleText("South America");
        Select Commands = new Select (driver.findElement(By.id("selenium_commands"))); //Select Continet
        Commands.selectByIndex(1);
        Thread.sleep(10000);
        
		//Completed Form Screenshot
		File CompletedForm = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CompletedForm, new File("C:/TC001_MobileAutomation/CompletedForm.jpg"));
		Thread.sleep(5000);	
        
        //Upload File
        WebElement uploadElement = driver.findElement(By.name("photo"));
        // enter the file path onto the file-selection input field
        uploadElement.sendKeys("C:\\C:\\TC001_ConfirmBooking_Cancel\\BookingConfirmed.jpg");
        Thread.sleep(10000);
        
        //Download File
        driver.findElement(By.xpath(".//a[@href='https://github.com/stanfy/behave-rest/blob/master/features/conf.yaml']")).click();
        Thread.sleep(10000);
        driver.navigate().back();
        Thread.sleep(10000);
        
        //Click on Submit button
        driver.findElement(By.id("submit")).click();
        Thread.sleep(10000);
        
        driver.quit();       
    
	}

}